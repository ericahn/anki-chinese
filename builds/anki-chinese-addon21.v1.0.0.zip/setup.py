from distutils.core import setup

setup(name='Pinyin',
      packages=['pinyin'],
      )
