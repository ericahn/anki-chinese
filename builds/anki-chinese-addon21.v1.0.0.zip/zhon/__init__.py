"""Provides constants used in Chinese text processing."""

__version__ = '1.1.5'
